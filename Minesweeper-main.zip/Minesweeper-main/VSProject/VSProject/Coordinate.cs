﻿//----------------------------------------------------------------------
// <copyright file="Coordinate.cs" company="😹👍">
//     team Project
// </copyright>
//----------------------------------------------------------------------
namespace VSProject
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// The class used to represent coordinates.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public class Coordinate
    {
        /// <summary>
        /// x coordinate of the board, the rows
        /// </summary>
        public int X;

        /// <summary>
        /// y coordinate of the game, the columns 
        /// </summary>
        public int Y;

        /// <summary>
        /// Initializes a new instance of the <see cref="Coordinate"/> class 
        /// </summary>
        public Coordinate()
        {
            this.X = 0;
            this.Y = 0;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Coordinate"/> class 
        /// </summary>
        /// <param name="x">the x value of the board. horizontal</param>
        /// <param name="y">the y value of the board. vertical</param>
        public Coordinate(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

        /// <summary>
        /// Generates random numbers and returns it as a random coordinate
        /// </summary>
        /// <param name="c"> the random column to pick</param>
        /// <param name="r"> the random row to pick</param>
        /// <returns> a integer value</returns>
        public static Coordinate GetRandomCoordinate(int c, int r)
        {
            Coordinate coord = new Coordinate();
            Random random = new Random();
            coord.X = random.Next(0, c);
            coord.Y = random.Next(0, r);
            return coord;
        }
    }
}
