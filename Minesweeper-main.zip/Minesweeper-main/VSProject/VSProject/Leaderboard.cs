﻿//----------------------------------------------------------------------
// <copyright file="Leaderboard.cs" company="😹👍">
//    team project
// </copyright>
//----------------------------------------------------------------------
namespace VSProject
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// leaderboard class to help store scores in a txt file by keeping track of the data
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public class Leaderboard
    {
        /// <summary>
        /// the initials of the user currently playing the game
        /// </summary>
        public string Initials;

        /// <summary>
        /// the number score of the individual currently playing the game
        /// </summary>
        public float Score;
    }
}
