﻿//----------------------------------------------------------------------
// <copyright file="LeaderboardWindow.xaml.cs" company="😹👍">
//     team project
// </copyright>
//----------------------------------------------------------------------
namespace VSProject
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;

    /// <summary>
    /// Interaction logic for LeaderboardWindow.xaml
    /// </summary>
    public partial class LeaderboardWindow : Window
    {
        /// <summary>
        /// the list of leaderboards
        /// </summary>
        private List<Leaderboard> leaderboards;

        /// <summary>
        /// Initializes a new instance of the  <see cref="LeaderboardWindow" /> class.
        /// </summary>
        public LeaderboardWindow()
        {
            this.InitializeComponent();
            this.leaderboards = new List<Leaderboard>();
            this.ReadFile();
            this.WriteFile();
        }

        /// <summary>
        /// gets the information in the leaderboard text file
        /// </summary>
        private void ReadFile()
        {
            StreamReader streamreader = new StreamReader("leaderboard.txt");
            
            while (!streamreader.EndOfStream)
            {
                string line = streamreader.ReadLine();
                string[] split = line.Split(' ');
                if (split.Length <= 1)
                {
                    return;
                }

                Leaderboard leaderboard1 = new Leaderboard();
                leaderboard1.Initials = split[0];
                if (float.TryParse(split[1], out leaderboard1.Score))
                {
                }

                this.leaderboards.Add(leaderboard1);
            }

            streamreader.Close();
        }

        /// <summary>
        /// add data to the leaderboard text file
        /// </summary>
        private void WriteFile()
        {
            this.LeaderboardLB.Items.Add("Highscores");
            this.LeaderboardLB.Items.Add("Name\t" + "Score");
            this.LoserboardLB.Items.Add("Low scores");
            this.LoserboardLB.Items.Add("Name\t" + "Score");

            this.leaderboards.Sort((x, y) => x.Score.CompareTo(y.Score));

            int length = this.leaderboards.Count();
            if (length > 5)
            {
                length = 5;
            }

            for (int i = this.leaderboards.Count() - 1; i >= this.leaderboards.Count() - length; i--)
            {
                this.LeaderboardLB.Items.Add(this.leaderboards[i].Initials + '\t' + this.leaderboards[i].Score);
            }

            for (int j = 0; j < length; j++)
            {
                this.LoserboardLB.Items.Add(this.leaderboards[j].Initials + '\t' + this.leaderboards[j].Score);
            }
        }
    }
}
