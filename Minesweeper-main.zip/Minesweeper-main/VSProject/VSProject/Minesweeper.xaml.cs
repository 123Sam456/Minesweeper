﻿//----------------------------------------------------------------------
// <copyright file="Minesweeper.xaml.cs" company="😹👍">
//     team project
// </copyright>
//----------------------------------------------------------------------
namespace VSProject
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Media;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    using System.Windows.Threading;

    /// <summary>
    /// Interaction logic for Minesweeper.xaml
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public partial class Minesweeper : Window
    {
        /// <summary>
        /// creates a timer for the game to keep track of time
        /// </summary>
        public DispatcherTimer Timer = new DispatcherTimer();

        /// <summary>
        /// represents one tenth of a second
        /// </summary>
        public int TenthsOfSecondsElapsed;

        /// <summary>
        /// instance of the game class
        /// </summary>
        public Game Game;

        /// <summary>
        /// an array of the number of images that are going to be in the game board
        /// </summary>
        public Image[,] Images;

        /// <summary>
        /// creates an instance of the grid that can be reused for the game 
        /// </summary>
        public Grid Gridd;

        /// <summary>
        /// placeholder for images
        /// </summary>
        public Canvas Canvass;

        /// <summary>
        /// row count
        /// </summary>
        public int Rows;

        /// <summary>
        /// columns count
        /// </summary>
        public int Columns;

        /// <summary>
        /// mine count
        /// </summary>
        public int Mines;

        /// <summary>
        /// tells whether the first click is safe or not
        /// </summary>
        public bool FirstClickSafe;

        /// <summary>
        /// the individual playing the game
        /// </summary>
        public int Player;

        /// <summary>
        /// text block to put the time in seconds
        /// </summary>
        private TextBlock timerText;

        /// <summary>
        /// restart button to get a new board of the same size but newly randomized bombs
        /// </summary>
        private Button restartButton;

        /// <summary>
        /// exit button to be able to go back to main window or to finish executing the whole game. 
        /// </summary>
        private Button exitButton;

        /// <summary>
        /// the initials of the user playing the game
        /// </summary>
        private string initials;

        /// <summary>
        /// the theme that the user chooses for the game in the main menu
        /// </summary>
        private int skinPack;

        /// <summary>
        /// Initializes a new instance of the <see cref="Minesweeper"/> class 
        /// </summary>
        /// <param name="rows"> the number of rows</param>
        /// <param name="columns"> the number of columns </param>
        /// <param name="mines"> the number of mines</param>
        /// <param name="firstClickSafe"> determine if the first click is guaranteed to be safe or not</param> 
        /// <param name="player"> who is playing the game, a living organism or a computer</param>
        /// <param name="initials"> the initials of the user playing the game</param>
        /// <param name="skinPack"> the theme chosen by the user</param>
        public Minesweeper(int rows, int columns, int mines, bool firstClickSafe, int player, string initials, int skinPack)
        {
            this.InitializeComponent();

            this.Rows = rows;
            this.Columns = columns;
            this.Mines = mines;
            this.FirstClickSafe = firstClickSafe;
            this.Player = player;
            this.initials = initials;
            this.skinPack = skinPack;

            this.Width = (columns * 25) + 200;
            this.Height = (rows * 25) + 200;
            this.Game = new Game(rows, columns, mines, this.Player);
            this.Game.FirstClick = true;
            this.Game.SafetyNet = firstClickSafe;

            this.Canvass = new Canvas();
            this.Content = this.Canvass;
            this.Canvass.Width = (columns * 25) + 200;
            this.Canvass.Height = (rows * 25) + 200;
            this.Canvass.Background = Brushes.LightSteelBlue;

            this.CreateGrid();
            this.CreateImages();
            this.Timer.Interval = TimeSpan.FromSeconds(1);
            this.Timer.Tick += this.Timer_Tick;
        }

        /// <summary>
        /// send match results to the leaderboard txt file
        /// </summary>
        /// <param name="time"> the total time to solve game</param>
        /// <param name="revealedSquares"> the number of squares revealed</param>
        private void WriteResultsToFile(float time, int revealedSquares)
        {
            float score = revealedSquares / time * 10;

            using (StreamWriter streamWriter = new StreamWriter("leaderboard.txt", true))
            {
                streamWriter.WriteLine(this.initials + ' ' + score.ToString());
            }
        }

        /// <summary>
        /// creates the grid for the game board with the number of rows and columns specified by the user 
        /// </summary>
        private void CreateGrid()
        {
            this.Gridd = new Grid();
            this.Gridd.Width = this.Game.Columns * 25;
            this.Gridd.Height = this.Game.Rows * 25;
            this.Gridd.HorizontalAlignment = HorizontalAlignment.Center;
            this.Gridd.VerticalAlignment = VerticalAlignment.Center;
            this.Gridd.ShowGridLines = true;

            for (int i = 0; i < this.Game.Rows; i++)
            {
                RowDefinition rd = new RowDefinition();
                this.Gridd.RowDefinitions.Add(rd);
            }

            for (int i = 0; i < this.Game.Columns; i++)
            {
                ColumnDefinition cd = new ColumnDefinition();
                this.Gridd.ColumnDefinitions.Add(cd);
            }

            Canvas.SetTop(this.Gridd, 25);
            Canvas.SetLeft(this.Gridd, 20);
            this.Canvass.Children.Add(this.Gridd);
            this.Gridd.MouseLeftButtonDown += this.GridLeftMouseDown;
            this.Gridd.MouseRightButtonDown += this.GridRightMouseDown;

            // textblock to display the timer 
            this.timerText = new TextBlock();
            this.timerText.Text = "0";
            Canvas.SetBottom(this.timerText, 150);
            Canvas.SetLeft(this.timerText, 20);
            this.Canvass.Children.Add(this.timerText);

            // button to restart a new game
            this.restartButton = new Button();
            this.restartButton.Content = "Restart";
            Canvas.SetBottom(this.restartButton, 100);
            Canvas.SetLeft(this.restartButton, 20);
            this.Canvass.Children.Add(this.restartButton);
            this.restartButton.Click += this.RestartButtonClick;

            // button to exit the game and go to the main menu=
            this.exitButton = new Button();
            this.exitButton.Content = "Exit";
            Canvas.SetBottom(this.exitButton, 100);
            Canvas.SetLeft(this.exitButton, 100);
            this.Canvass.Children.Add(this.exitButton);
            this.exitButton.Click += this.ExitButtonClick;

            if (this.Player > 0)
            {
                Button nextMoveButton = new Button();
                nextMoveButton.Content = "GPT, make your next move";
                Canvas.SetBottom(nextMoveButton, 150);
                Canvas.SetLeft(nextMoveButton, 200);
                this.Canvass.Children.Add(nextMoveButton);
                nextMoveButton.Click += this.NextMoveButtonClick;
            }
        }

        /// <summary>
        /// makes the computer player flag or uncover more squares along with a click sound
        /// </summary>
        /// <param name="sender">The parameter is not used</param>
        /// <param name="e">The parameter is not used v2</param>
        private void NextMoveButtonClick(object sender, RoutedEventArgs e)
        {
            SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.mouseclick);
            soundPlayer.Play();
            this.MakeMove();
        }

        /// <summary>
        /// the way computer player will play based on it's IQ 
        /// determines how the minefield acts based on first click settings
        /// </summary>
        private void MakeMove()
        {
            // If first click make board and make sure they don't click on mine
            if (this.Game.FirstClick)
            {
                SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.reveal);
                soundPlayer.Play();

                // The player already made his first click
                this.Game.FirstClick = false;
                Coordinate coord = Coordinate.GetRandomCoordinate(this.Columns, this.Rows);
                this.Game.StartSafeGame(coord);
                this.Game.GPT.RevealedCoords.Add(coord);
                this.Game.Minefield.Squares[coord.X, coord.Y].Revealed = true;
                this.ChangeImageOnState(this.Game.Minefield.Squares[coord.X, coord.Y].State, coord);
                this.SearchMines(coord);

                this.Timer.Start();
                this.TenthsOfSecondsElapsed = 0;
                return;
            }

            // Random uncover green squares AI
            if (this.Player == 1)
            {
                Coordinate selection = this.Game.GPT.RandomizeSelection();
                State s = this.Game.Minefield.Squares[selection.X, selection.Y].State;
                this.EndGame(selection);
            }
            else if (this.Player == 2)
            {
                // The smart logical AI
                // get a coord of 100% or close
                Coordinate i = this.Game.GPT.FindHighestCoordPercent(this.Game.Minefield.Columns, this.Game.Minefield.Rows);

                // recursion
                this.SmartAI(i);
            }
        }

        /// <summary>
        /// Decides what to do with the percent and coordinate given for squares
        /// </summary>
        /// <param name="coord"> the coordinate</param>
        private void SmartAI(Coordinate coord)
        {
            Coordinate dumby;
            List<Coordinate> dumbylist;
            int percent = this.Game.GPT.MinePercent(coord);
            int sNum;
            int sFlag;
            int sGrass;

            // flag any surrounding squares
            if (percent == 100)
            {
                dumby = this.Game.GPT.FlagCoords(coord);
                this.ChangeImageOnState2(State2.Question, dumby);
                sNum = this.Game.GPT.GetStateNumber(dumby);
                sFlag = this.Game.GPT.SurroundingFlagged(dumby);
                sGrass = this.Game.GPT.SurroundingGreen(dumby);
                dumbylist = this.Game.Minefield.GetSurroundingCoordinates(dumby);
                for (int b = 0; b < dumbylist.Count(); b++)
                {
                    if (this.Game.Minefield.Squares[dumbylist[b].X, dumbylist[b].Y].Revealed == true && this.Game.GPT.RevealedCoords.Contains(dumbylist[b]) == false)
                    {
                        sNum = this.Game.GPT.GetStateNumber(dumbylist[b]);
                        sFlag = this.Game.GPT.SurroundingFlagged(dumbylist[b]);
                        sGrass = this.Game.GPT.SurroundingGreen(dumbylist[b]);
                        if (sNum == sFlag && sGrass == 0)
                        {
                            this.Game.GPT.RevealedCoords.Add(dumbylist[b]);
                        }
                    }
                }
            }
            else if (percent == 101)
            {
                // dig up any surrounding green squares
                dumby = this.Game.GPT.UncoverCoords(coord);

                this.EndGame(dumby);
            }
            else if (percent >= 102)
            {
                if (percent == 102)
                {
                    // Uncover bottom
                    if (this.Game.GPT.CheckFlagged(new Coordinate(coord.X, coord.Y + 1)) == false)
                    {
                        this.EndGame(new Coordinate(coord.X, coord.Y + 1));
                    }
                }
                else if (percent == 103) 
                {
                    // Uncover top
                    if (this.Game.GPT.CheckFlagged(new Coordinate(coord.X, coord.Y - 1)) == false)
                    {
                        this.EndGame(new Coordinate(coord.X, coord.Y - 1));
                    }
                }
                else if (percent == 104)
                {
                    // Uncover left
                    if (this.Game.GPT.CheckFlagged(new Coordinate(coord.X - 1, coord.Y)) == false)
                    {
                        this.EndGame(new Coordinate(coord.X - 1, coord.Y));
                    }
                }
                else if (percent == 105)
                {
                    // Uncover right
                    if (this.Game.GPT.CheckFlagged(new Coordinate(coord.X + 1, coord.Y)) == false)
                    {
                        this.EndGame(new Coordinate(coord.X + 1, coord.Y));
                    }
                }
            }
            else
            {
                // pick a random square that we arent sure of
                // Choosing random numbers to pick
                Random rand = new Random();
                int xNum = rand.Next(0, 2);
                int yNum = rand.Next(0, 2);
                while (true)
                {
                    if (this.Game.GPT.PrevChecked(new Coordinate(xNum, yNum)) || !this.Game.GPT.CheckInBounds(new Coordinate(coord.X + xNum - 1, coord.Y + yNum - 1)))
                    {
                        xNum = rand.Next(0, 2);
                        yNum = rand.Next(0, 2);
                    }
                    else
                    {
                        break;
                    }
                }

                dumby = new Coordinate(coord.X + xNum - 1, coord.Y + yNum - 1);
                this.EndGame(dumby);
            }

            // Adding coords
            sNum = this.Game.GPT.GetStateNumber(coord);
            sFlag = this.Game.GPT.SurroundingFlagged(coord);
            sGrass = this.Game.GPT.SurroundingGreen(coord);
            if (sNum == sFlag && sGrass == 0 && this.Game.GPT.RevealedCoords.Contains(coord) == false)
            {
                this.Game.GPT.RevealedCoords.Add(coord);
            }
        }

        /// <summary>
        /// Decides whether you get an extra chance or not after you click on a mine
        /// </summary>
        /// <returns> whether you get a second chance or not</returns>
        private bool LuckyChance()
        {
            Random random = new Random();

            // generate a random number between 1 and 10 (inclusive)
            int randomNumber = random.Next(1, 11); 

            if (randomNumber == 10)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Changes the image and checks the lose and win condition
        /// chance to keep going even if clicked on a mine
        /// </summary>
        /// <param name="coord"> the coordinate</param>
        private void EndGame(Coordinate coord)
        {
            State state = this.Game.GetSquare(coord).State;
            this.ChangeImageOnState(state, coord);

            // If they click on a mine
            if (state == State.IsAMine)
            {
                if (!this.LuckyChance())
                {
                    SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.explosion);
                    soundPlayer.Play();
                    this.RevealAllMines();
                    this.Timer.Stop();
                    this.WriteResultsToFile(this.TenthsOfSecondsElapsed / 1f, this.Game.LeftClicks);
                    MessageBoxResult result = MessageBox.Show("Game over? yes to quit no to retry", "Game Over 😿", MessageBoxButton.YesNo, MessageBoxImage.Hand);
                    if (result == MessageBoxResult.Yes)
                    {
                        this.Exit();
                    }
                    else
                    {
                        this.Restart();
                    }
                }
                else
                {
                    MessageBox.Show("You get another chance!");
                }
            }
            else if (state == State.NoMines)
            {
                // If the user clicked a blank
                if (this.Player > 0)
                {
                    this.Game.GPT.RevealedCoords.Add(coord);
                }
                
                this.SearchMines(coord);
            }
            else if (!this.Game.GetRevealed(coord))
            {
            }

            if (this.Game.CheckWinCondition())
            {
                this.WriteResultsToFile(this.TenthsOfSecondsElapsed, this.Game.LeftClicks);
                this.Timer.Stop();
                MessageBox.Show("You win");
            }
        }

        /// <summary>
        /// Restart button event
        /// </summary>
        /// <param name="sender">The parameter is not used</param>
        /// <param name="e">The parameter is not used v2</param>
        private void RestartButtonClick(object sender, RoutedEventArgs e)
        {
            this.Restart();
        }

        /// <summary>
        /// Exit button event
        /// </summary>
        /// <param name="sender">The parameter is not used</param>
        /// <param name="e">The parameter is not used v2</param>
        private void ExitButtonClick(object sender, RoutedEventArgs e)
        {
            this.Exit();
        }

        /// <summary>
        /// restart method to keep settings but on a new minefield 
        /// </summary>
        private void Restart()
        {
            Minesweeper minesweeper = new Minesweeper(this.Rows, this.Columns, this.Mines, this.FirstClickSafe, this.Player, this.initials, this.skinPack);
            minesweeper.Show();
            this.Close();
        }

        /// <summary>
        /// exit method
        /// </summary>
        private void Exit()
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }

        /// <summary>
        /// timer to keep time moving when playing 
        /// </summary>
        /// <param name="sender">The parameter is not used</param>
        /// <param name="e">The parameter is not used v2</param>
        private void Timer_Tick(object sender, EventArgs e)
        {
            this.TenthsOfSecondsElapsed++;
            this.timerText.Text = (this.TenthsOfSecondsElapsed / 1f).ToString("0s");
        }

        /// <summary>
        /// create images for the game board at the beginning of the game
        /// default images for squares is covered blank square. 
        /// looks different depending on the skin pack chosen in the main window
        /// </summary>
        private void CreateImages()
        {
            this.Images = new Image[this.Game.Columns, this.Game.Rows];
            for (int i = 0; i < this.Game.Columns; i++)
            {
                for (int j = 0; j < this.Game.Rows; j++)
                {
                    Image image = new Image();
                    image.Width = 25;
                    image.Height = 25;
                    BitmapImage bi3 = new BitmapImage();
                    bi3.BeginInit();
                    switch (this.skinPack)
                    {
                        case 0:
                            bi3.UriSource = new Uri("Images/Winter/snow.jpg", UriKind.Relative);
                            break;
                        case 1:
                            bi3.UriSource = new Uri("Images/alphabet/Purple.jpg", UriKind.Relative);
                            break;
                        case 2:
                            bi3.UriSource = new Uri("Images/SummerBeach/Sand.jpg", UriKind.Relative);
                            break;
                        case 3:
                            bi3.UriSource = new Uri("Images/normal/Grass.png", UriKind.Relative);
                            break;
                        case 4:
                            bi3.UriSource = new Uri("Images/space/Space.jpg", UriKind.Relative);
                            break;
                        case 5:
                            bi3.UriSource = new Uri("Images/Binary/BinaryBlank.jpg", UriKind.Relative);
                            break;
                        default:
                            bi3.UriSource = new Uri("Images/normal/Grass.png", UriKind.Relative);
                            break;
                    }

                    bi3.EndInit();
                    image.Source = bi3;
                    Grid.SetColumn(image, i);
                    Grid.SetRow(image, j);
                    this.Gridd.Children.Add(image);
                    this.Images[i, j] = image;
                }
            }
        }

        /// <summary>
        /// the click event for when the left side of the mouse is clicked while it is positioned above the board
        /// changes state of the square depending on if its uncovered or not. 
        /// </summary>
        /// <param name="sender"> a sender for something</param>
        /// <param name="e"> the letter e</param>
        private void GridLeftMouseDown(object sender, RoutedEventArgs e)
        {
            if (this.Player > 0)
            {
                return;
            }      
            
            Coordinate coordinate = this.GetMouseClickCoordinates(); // Get coordinates of the first 

            SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.mouseclick);
            soundPlayer.Play();

            if (this.Game.FirstClick)
            {
                SoundPlayer firstsoundPlayer = new SoundPlayer(Properties.Resources.reveal);
                firstsoundPlayer.Play();
                
                // The player already made his first click
                this.Game.FirstClick = false;
                if (this.Game.SafetyNet)
                {
                    this.Game.StartSafeGame(coordinate);
                }
                else
                {
                    this.Game.StartGame();
                }

                this.Timer.Start();
                this.TenthsOfSecondsElapsed = 0;
            }

            State state = this.Game.GetSquare(coordinate).State;
            State2 state2 = this.Game.GetSquare(coordinate).State2;

            if (state2 != State2.Flag)
            {
                this.EndGame(coordinate);
            }
        }

        /// <summary>
        /// the click event for when the user clicks this right side of the mouse while it is above the grid
        /// rotates over 3 states of covered, flag, or question mark
        /// for uncovered squares only
        /// </summary>
        /// <param name="sender"> a sender for something</param>
        /// <param name="e"> the letter e</param>
        private void GridRightMouseDown(object sender, RoutedEventArgs e)
        {
            if (this.Game.FirstClick)
            {
                return;
            } 

            Coordinate coordinate = this.GetMouseClickCoordinates();

            if (this.Game.GetSquare(coordinate).Revealed)
            {
                return;
            }

            SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.flag);
            soundPlayer.Play();

            State2 state = this.Game.GetSquare(coordinate).State2;

            this.ChangeImageOnState2(state, coordinate);
        }

        /// <summary>
        /// method to reveal all the mines that were randomly placed on the field. 
        /// </summary>
        private void RevealAllMines()
        {
            SoundPlayer soundPlayer = new SoundPlayer(Properties.Resources.explosion);
            soundPlayer.Play();
            foreach (Coordinate c in this.Game.GetAllMines())
            {
                this.ChangeImageOnState(State.IsAMine, c);
            }
        }

        /// <summary>
        /// a method to get the coordinates of the mouse cursor when either mouse button is clicked 
        /// </summary>
        /// <returns> returns a instance of the coordinate class which includes the coordinates of the location of the mouse when one of its button were clicked</returns>
        private Coordinate GetMouseClickCoordinates()
        {
            Point mousePosition = Mouse.GetPosition(this.Gridd);
            double doubleX = Math.Floor(mousePosition.X);
            double doubleY = Math.Floor(mousePosition.Y);
            int x = Convert.ToInt32(doubleX);
            int y = Convert.ToInt32(doubleY);

            x /= 25;
            y /= 25;
            Coordinate coordinate = new Coordinate(x, y);
            return coordinate;
        }

        /// <summary>
        /// change the image displayed for a square when it is interacted with. 
        /// revealed square images and the empty unrevealed square
        /// </summary>
        /// <param name="s"> the current state of the square</param>
        /// <param name="c"> the coordinates of the square imported into the method</param>
        private void ChangeImageOnState(State s, Coordinate c)
        {
            this.Game.LeftClicks++;
            BitmapImage bi3 = new BitmapImage();

            bi3.BeginInit();

            switch (this.skinPack)
            {
                case 0:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnow.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowOne.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowTwo.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowThree.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowFour.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowFive.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowSix.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowSeven.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowEight.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/Winter/RevealedSnowBomb2.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
                case 1:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurple.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleOne.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleTwo.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleThree.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleFour.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleFive.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleSix.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleSeven.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleEight.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/alphabet/RevealedPurpleBomb.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
                case 2:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSand.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandOne.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandTwo.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandThree.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandFour.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandFive.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandSix.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandSeven.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandEight.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/SummerBeach/RevealedSandBomb.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
                case 3:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/normal/Blank.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/normal/1.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/normal/2.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/normal/3.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/normal/4.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/normal/5.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/normal/6.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/normal/7.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/normal/8.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/normal/Bomb.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
                case 4:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpace.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceOne.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceTwo.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceThree.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceFour.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceFive.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceSix.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceSeven.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceEight.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/space/RevealedSpaceBomb.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
                case 5:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryBlank.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryOne.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryTwo.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryThree.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryFour.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryFive.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinarySix.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinarySeven.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryEight.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/Binary/RevealedBinaryBomb.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
                default:
                    switch (s)
                    {
                        case State.NoMines:
                            bi3.UriSource = new Uri("Images/normal/Blank.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.OneMine:
                            bi3.UriSource = new Uri("Images/normal/1.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.TwoMines:
                            bi3.UriSource = new Uri("Images/normal/2.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.ThreeMines:
                            bi3.UriSource = new Uri("Images/normal/3.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FourMines:
                            bi3.UriSource = new Uri("Images/normal/4.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.FiveMines:
                            bi3.UriSource = new Uri("Images/normal/5.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SixMines:
                            bi3.UriSource = new Uri("Images/normal/6.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.SevenMines:
                            bi3.UriSource = new Uri("Images/normal/7.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.EightMines:
                            bi3.UriSource = new Uri("Images/normal/8.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                        case State.IsAMine:
                            bi3.UriSource = new Uri("Images/normal/Bomb.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetRevealed(c, true);
                            break;
                    }

                    break;
            }
        }

        /// <summary>
        /// the different images possible when a square is undiscovered
        /// it also includes the empty unrevealed square image 
        /// </summary>
        /// <param name="s"> the current state of a block</param>
        /// <param name="c"> the current coordinate of the block imported into the method</param>
        private void ChangeImageOnState2(State2 s, Coordinate c)
        {
            BitmapImage bi3 = new BitmapImage();
            
            bi3.BeginInit();

            switch (this.skinPack)
            {
                case 0:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/Winter/snowQuestion.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/Winter/snowFlag.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/Winter/snow.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
                case 1:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/alphabet/PurpleQuestion.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/alphabet/PurpleFlag.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/alphabet/Purple.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
                case 2:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/SummerBeach/SandQuestion.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/SummerBeach/SandFlag.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/SummerBeach/Sand.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
                case 3:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/normal/Grass_Question.png", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/normal/Grass_Flag.png", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/normal/Grass.png", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
                case 4:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/space/SpaceQuestion.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/space/SpaceFlag.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/space/Space.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
                case 5:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/Binary/BinaryBlankQuestion.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/Binary/BinaryBlankFlag.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/Binary/BinaryBlankBlank.jpg", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
                default:
                    switch (s)
                    {
                        case State2.Blank:
                            bi3.UriSource = new Uri("Images/normal/Grass_Question.png", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Question, c);
                            break;
                        case State2.Question:
                            bi3.UriSource = new Uri("Images/normal/Grass_Flag.png", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Flag, c);
                            break;
                        case State2.Flag:
                            bi3.UriSource = new Uri("Images/normal/Grass.png", UriKind.Relative);
                            bi3.EndInit();
                            this.Images[c.X, c.Y].Source = bi3;
                            this.Game.SetState2(State2.Blank, c);
                            break;
                    }

                    break;
            }
        }

        /// <summary>
        /// a method to search for all the mines placed on the the grid/game board
        /// </summary>
        /// <param name="coordinate"> instance of the coordinate class that include the x and y coordinates</param>
        private void SearchMines(Coordinate coordinate)
        {
            if (this.Game.Minefield.IsCoordinateValid(coordinate))
            {
                for (int xNum = coordinate.X - 1; xNum <= coordinate.X + 1; xNum++)
                {
                    for (int yNum = coordinate.Y - 1; yNum <= coordinate.Y + 1; yNum++)
                    {
                        // if outside Minefield area BORDERS!! OR ALREADY REVEALED
                        if (this.Game.Minefield.IsCoordinateValid(new Coordinate(xNum, yNum)))
                        {
                            if (this.Game.Minefield.Squares[xNum, yNum].Revealed != true)
                            {
                                if (this.Game.Minefield.Squares[xNum, yNum].State == State.NoMines)
                                {
                                    this.ChangeImageOnState(State.NoMines, new Coordinate(xNum, yNum));
                                    this.Game.Minefield.Squares[xNum, yNum].Revealed = true;
                                    if (this.Player > 0)
                                    {
                                        // Adding coords
                                        int sNum = this.Game.GPT.GetStateNumber(new Coordinate(xNum, yNum));
                                        int sFlag = this.Game.GPT.SurroundingFlagged(new Coordinate(xNum, yNum));
                                        int sGrass = this.Game.GPT.SurroundingGreen(new Coordinate(xNum, yNum));

                                        if ((sNum == sFlag && sGrass == 0) && this.Game.GPT.RevealedCoords.Contains(new Coordinate(xNum, yNum)) == false)
                                        {
                                            this.Game.GPT.RevealedCoords.Add(new Coordinate(xNum, yNum));
                                        }
                                    }

                                    this.SearchMines(new Coordinate(xNum, yNum));
                                }
                                else
                                {
                                    State state = this.Game.Minefield.Squares[xNum, yNum].State;
                                    this.ChangeImageOnState(state, new Coordinate(xNum, yNum));
                                    this.Game.Minefield.Squares[xNum, yNum].Revealed = true;
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}