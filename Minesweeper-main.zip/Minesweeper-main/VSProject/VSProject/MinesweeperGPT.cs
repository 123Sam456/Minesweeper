﻿//----------------------------------------------------------------------
// <copyright file="MinesweeperGPT.cs" company="😹👍">
//     copyright  header 
// </copyright>
//----------------------------------------------------------------------
namespace VSProject
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// the computer player
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public class MinesweeperGPT
    {
        /// <summary>
        /// the minefield for the user to interact with to be able to play 
        /// </summary>
        public Minefield GameMinefield;

        /// <summary>
        /// the coordinates that the computer player has already revealed are going to be stored in a list 
        /// </summary>
        public List<Coordinate> RevealedCoords;

        /// <summary>
        /// the coordinate that is being checked/used 
        /// </summary>
        public Coordinate CurrentCoord;

        /// <summary>
        /// the coordinates of the squares surrounding a single square
        /// </summary>
        public List<Coordinate> SurroundingCoords;

        /// <summary>
        /// Initializes a new instance of the <see cref="MinesweeperGPT"/> class 
        /// </summary>
        /// <param name="mf"> the minefield</param>
        public MinesweeperGPT(Minefield mf)
        {
            this.GameMinefield = mf;
            this.RevealedCoords = new List<Coordinate>();
        }

        /// <summary>
        /// Gets random coordinate to click
        /// </summary>
        /// <returns> a coordinate</returns>
        public Coordinate RandomizeSelection()
        {
            // Runs until lost or won
            bool valid = false;
            while (!valid)    
            {
                Coordinate selection = Coordinate.GetRandomCoordinate(this.GameMinefield.Columns, this.GameMinefield.Rows);
                if (this.GameMinefield.Squares[selection.X, selection.Y].Revealed == true)
                {
                    valid = false;
                }
                else
                {
                    this.RevealedCoords.Add(selection);
                    this.GameMinefield.Squares[selection.X, selection.Y].Revealed = true;
                    return selection;
                }
            }

            return null;
        }

        /// <summary>
        /// takes in a coordinate and checks if that coordinate is in the revealed list
        /// </summary>
        /// <param name="coord"> the coordinate </param>
        /// <returns> a boolean</returns>
        public bool PrevChecked(Coordinate coord)
        {
            return this.RevealedCoords.Contains(coord);
        }

        /// <summary>
        /// Returns the number of surrounding Green Squares
        /// </summary>
        /// <param name="coordinate"> chooses a coordinate to pick and interact with</param>
        /// <returns> integer of number of green squares</returns>
        public int SurroundingGreen(Coordinate coordinate)
        {
            int gNumber = 0;
            for (int xNum = coordinate.X - 1; xNum <= coordinate.X + 1; xNum++)
            {
                for (int yNum = coordinate.Y - 1; yNum <= coordinate.Y + 1; yNum++)
                {
                    if (this.CheckInBounds(new Coordinate(xNum, yNum)) == true)
                    {
                        if (this.GameMinefield.Squares[xNum, yNum].Revealed != true)
                        {
                            State2 s = this.GameMinefield.Squares[xNum, yNum].State2;
                            if (s != State2.Flag)
                            {
                                gNumber++;
                            }
                        }
                    }
                }
            }

            return gNumber;
        }

        /// <summary>
        /// Returns the number of surrounding Flagged Squares
        /// </summary>
        /// <param name="coordinate"> chooses a coordinate to pick and interact with</param>
        /// <returns> a integer of surrounding flags</returns>
        public int SurroundingFlagged(Coordinate coordinate)
        {
            int fNumber = 0;
            for (int xNum = coordinate.X - 1; xNum <= coordinate.X + 1; xNum++)
            {
                for (int yNum = coordinate.Y - 1; yNum <= coordinate.Y + 1; yNum++)
                {
                    if (this.CheckInBounds(new Coordinate(xNum, yNum)) == true)
                    {
                        State2 s = this.GameMinefield.Squares[xNum, yNum].State2;
                        if (this.GameMinefield.Squares[xNum, yNum].Revealed != true)
                        {
                            if (s == State2.Flag)
                            {
                                fNumber++;
                            }
                            
                            if (fNumber == this.GetStateNumber(coordinate))
                            {
                                break;
                            }
                        }
                    }
                }
            }

            return fNumber;
        }

        /// <summary>
        /// Gets the number square it is
        /// </summary>
        /// <param name="coordinate"> chooses a coordinate to pick and interact with</param>
        /// <returns> the current image of the square</returns>
        public int GetStateNumber(Coordinate coordinate)
        {
            int sNumber = 0;
            State s = this.GameMinefield.Squares[coordinate.X, coordinate.Y].State;
            switch (s)
            {
                case State.NoMines:
                    sNumber = 0;
                    break;
                case State.OneMine:
                    sNumber = 1;
                    break;
                case State.TwoMines:
                    sNumber = 2;
                    break;
                case State.ThreeMines:
                    sNumber = 3;
                    break;
                case State.FourMines:
                    sNumber = 4;
                    break;
                case State.FiveMines:
                    sNumber = 5;
                    break;
                case State.SixMines:
                    sNumber = 6;
                    break;
                case State.SevenMines:
                    sNumber = 7;
                    break;
                case State.EightMines:
                    sNumber = 8;
                    break;
            }

            return sNumber;
        }

        /// <summary>
        /// Returns the coordinates of flags around itself
        /// </summary>
        /// <param name="coord"> chooses a coordinate to pick and interact with</param>
        /// <returns> returns a coordinate</returns>
        public Coordinate FlagCoords(Coordinate coord)
        {
            for (int xNum = coord.X - 1; xNum <= coord.X + 1; xNum++)
            {
                for (int yNum = coord.Y - 1; yNum <= coord.Y + 1; yNum++)
                {
                    if (this.CheckInBounds(new Coordinate(xNum, yNum)))
                    {
                        if ((this.GameMinefield.Squares[xNum, yNum].Revealed != true) && !this.CheckFlagged(new Coordinate(xNum, yNum)) && this.RevealedCoords.Contains(new Coordinate(xNum, yNum)) == false)
                        {
                            this.CurrentCoord = new Coordinate(xNum, yNum);
                            return this.CurrentCoord;
                        }
                    }
                }
            }

            return this.CurrentCoord;
        }

        /// <summary>
        /// Uncovers any coordinates that are green and recalls the probability method
        /// </summary>
        /// <param name="coord"> chooses a coordinate to pick and interact with</param>
        /// <returns>no uncovered coordinates</returns>
        public Coordinate UncoverCoords(Coordinate coord)
        {
            for (int xNum = coord.X - 1; xNum <= coord.X + 1; xNum++)
            {
                for (int yNum = coord.Y - 1; yNum <= coord.Y + 1; yNum++) 
                { 
                    if (this.CheckInBounds(new Coordinate(xNum, yNum)))
                    {
                        if ((this.GameMinefield.Squares[xNum, yNum].Revealed == false) && (this.CheckFlagged(new Coordinate(xNum, yNum)) == false) && (this.CheckInBounds(new Coordinate(xNum, yNum)) == true))
                        {
                            this.CurrentCoord = new Coordinate(xNum, yNum);
                            return this.CurrentCoord;
                        }
                    }
                }
            }

            return this.CurrentCoord;
        }

        /// <summary>
        /// Checks if the coordinates given are in bounds
        /// </summary>
        /// <param name="coord"> chooses a coordinate to pick and interact with</param>
        /// <returns> whether a square is in bounds or not</returns>
        public bool CheckInBounds(Coordinate coord)
        {
            bool inn = this.GameMinefield.IsCoordinateValid(coord);
            return inn;
        }

        /// <summary>
        /// Check the state2 if the square is flagged or not returns true if yes false no
        /// </summary>
        /// <param name="coord"> chooses a coordinate to pick and interact with</param>
        /// <returns> whether a square is flagged or not</returns>
        public bool CheckFlagged(Coordinate coord)
        {
            bool inn = false;
            State2 s = this.GameMinefield.Squares[coord.X, coord.Y].State2;

            if (s == State2.Flag)
            {
                inn = true;
            }
            else
            {
                inn = false;
            }

            return inn;
        }

        /// <summary>
        /// Return the percentage the in which we can determine the location of mines around it
        /// </summary>
        /// <param name="coord"> chooses a coordinate to pick and interact with</param>
        /// <returns> how likely a square is to have a mine</returns>
        public int MinePercent(Coordinate coord)
        {
            int percent = 0;
            if (this.GameMinefield.Squares[coord.X, coord.Y].Revealed && !this.RevealedCoords.Contains(coord))
            {
                int sNum = this.GetStateNumber(coord);

                // If square blank
                if (sNum != 0)
                {
                    int sFlag = this.SurroundingFlagged(coord);
                    int sGrass = this.SurroundingGreen(coord);

                    if (sNum == sFlag && sGrass == 0 && !this.RevealedCoords.Contains(coord))
                    {
                        this.RevealedCoords.Add(coord);
                        return percent;
                    }

                    if ((sFlag + sGrass == sNum) || (sNum == sGrass && sFlag == 0))
                    {
                        // Flag all blanks
                        percent = 100;
                        return percent;
                    }

                    if (sNum == sFlag && sGrass > 0)
                    {
                        // uncover all blanks
                        percent = 101;
                        return percent;
                    }

                    // Checking if left, right, top, bottom are all inbounds
                    if (this.CheckInBounds(new Coordinate(coord.X + 1, coord.Y)) && this.CheckInBounds(new Coordinate(coord.X - 1, coord.Y)) && this.CheckInBounds(new Coordinate(coord.X, coord.Y + 1)) && this.CheckInBounds(new Coordinate(coord.X, coord.Y - 1)))
                    {
                        // right and left
                        if (this.GameMinefield.Squares[coord.X + 1, coord.Y].Revealed && this.GameMinefield.Squares[coord.X - 1, coord.Y].Revealed)
                        {
                            // Checking if the top are all revealed
                            if (this.GameMinefield.Squares[coord.X - 1, coord.Y - 1].Revealed && this.GameMinefield.Squares[coord.X + 1, coord.Y - 1].Revealed && this.GameMinefield.Squares[coord.X, coord.Y - 1].Revealed && (this.GameMinefield.Squares[coord.X, coord.Y + 1].Revealed == false))
                            {
                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 2 && this.GetStateNumber(new Coordinate(coord.X + 1, coord.Y)) == 1 && this.GetStateNumber(new Coordinate(coord.X - 1, coord.Y)) == 1)
                                {
                                    // return 102 if the top is already revealed and in a 1 2 1 format of each other
                                    percent = 102;
                                    return percent;
                                }

                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 1 && this.GetStateNumber(new Coordinate(coord.X + 1, coord.Y)) == 2 && this.GetStateNumber(new Coordinate(coord.X - 1, coord.Y)) == 2)
                                {
                                    // return 102 if the top is already revealed and in a 2 1 2 format of each other
                                    percent = 102;
                                    return percent;
                                }
                            }

                            // Checking if the bottom are all revealed
                            if (this.GameMinefield.Squares[coord.X - 1, coord.Y + 1].Revealed && this.GameMinefield.Squares[coord.X + 1, coord.Y + 1].Revealed && this.GameMinefield.Squares[coord.X, coord.Y + 1].Revealed && (this.GameMinefield.Squares[coord.X, coord.Y - 1].Revealed == false))
                            {
                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 2 && this.GetStateNumber(new Coordinate(coord.X + 1, coord.Y)) == 1 && this.GetStateNumber(new Coordinate(coord.X - 1, coord.Y)) == 1)
                                {
                                    // return 103 if the bottom is already revealed and in a 1 2 1 format of each other
                                    percent = 103;
                                    return percent;
                                }

                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 1 && this.GetStateNumber(new Coordinate(coord.X + 1, coord.Y)) == 2 && this.GetStateNumber(new Coordinate(coord.X - 1, coord.Y)) == 2)
                                {
                                    // return 103 if the bottom is already revealed and in a 2 1 2 format of each other
                                    percent = 103;
                                    return percent;
                                }
                            }
                        }

                        // up and down
                        if (this.GameMinefield.Squares[coord.X, coord.Y - 1].Revealed && this.GameMinefield.Squares[coord.X, coord.Y + 1].Revealed)
                        {
                            // Checking if the right side are revealed
                            if (this.GameMinefield.Squares[coord.X + 1, coord.Y - 1].Revealed && this.GameMinefield.Squares[coord.X + 1, coord.Y + 1].Revealed && this.GameMinefield.Squares[coord.X + 1, coord.Y].Revealed && this.GameMinefield.Squares[coord.X + 1, coord.Y].Revealed == false)
                            {
                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 2 && this.GetStateNumber(new Coordinate(coord.X, coord.Y + 1)) == 1 && this.GetStateNumber(new Coordinate(coord.X, coord.Y - 1)) == 1)
                                {
                                    // return 104 if the right is already revealed and in a 1 2 1 format of each other
                                    percent = 104;
                                    return percent;
                                }

                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 1 && this.GetStateNumber(new Coordinate(coord.X, coord.Y + 1)) == 2 && this.GetStateNumber(new Coordinate(coord.X, coord.Y - 1)) == 2)
                                {
                                    // return 104 if the right is already revealed and in a 2 1 2 format of each other
                                    percent = 104;
                                    return percent;
                                }
                            }

                            // Checking if the left side are all revealed
                            if (this.GameMinefield.Squares[coord.X - 1, coord.Y + 1].Revealed && this.GameMinefield.Squares[coord.X - 1, coord.Y - 1].Revealed && this.GameMinefield.Squares[coord.X - 1, coord.Y].Revealed && (this.GameMinefield.Squares[coord.X - 1, coord.Y].Revealed == false))
                            {
                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 2 && this.GetStateNumber(new Coordinate(coord.X, coord.Y + 1)) == 1 && this.GetStateNumber(new Coordinate(coord.X, coord.Y - 1)) == 1)
                                {
                                    // return 105 if the left is already revealed and in a 2 1 2 format of each other
                                    percent = 105;
                                    return percent;
                                }

                                if (this.GetStateNumber(new Coordinate(coord.X, coord.Y)) == 1 && this.GetStateNumber(new Coordinate(coord.X, coord.Y + 1)) == 2 && this.GetStateNumber(new Coordinate(coord.X, coord.Y - 1)) == 2)
                                {
                                    // return 105 if the left is already revealed and in a 2 1 2 format of each other
                                    percent = 105;
                                    return percent;
                                }
                            }
                        }
                    }

                percent = this.GetPercent(sNum, sFlag, sGrass);
                }
            }

            return percent;
        }

        /// <summary>
        /// When the Grass divides it automatically converts to zero that why I had to make a method
        /// </summary>
        /// <param name="sNumber"> the number</param>
        /// <param name="sFlag"> the flag</param>
        /// <param name="sGreen"> the green</param>
        /// <returns> the percentage in a square</returns>
        public int GetPercent(int sNumber, int sFlag, int sGreen)
        {
            double i = sNumber;
            i = i - sFlag;
            i = i / sGreen;
            i = i * 100;

            return (int)i;
        }

        /// <summary>
        /// find the highest percentage
        /// </summary>
        /// <param name="columns"> the columns</param>
        /// <param name="rows"> the rows</param>
        /// <returns> the coordinate of square with highest percentage</returns>
        public Coordinate FindHighestCoordPercent(int columns, int rows)
        {
            Coordinate woo = new Coordinate(0, 0);
            int percent = -1;
            int percent2 = -1;

            for (int xNum = 0; xNum < columns; xNum++)
            {
                for (int yNum = 0; yNum < rows; yNum++)
                {
                    // If it isnt in the revealedCoords
                    if (this.GameMinefield.Squares[xNum, yNum].Revealed == true)
                    {
                        // If not blank
                        if (this.GetStateNumber(new Coordinate(xNum, yNum)) != 0 && !this.RevealedCoords.Contains(new Coordinate(xNum, yNum)))
                        {
                            percent2 = this.MinePercent(new Coordinate(xNum, yNum));

                            // If 100% sure then we dont need to find a higher one
                            if (percent2 >= 100)
                            {
                                return new Coordinate(xNum, yNum);
                            }

                            // If the new percent has a higher chance of bomb than other change
                            if (percent2 > percent)
                            {
                                percent = percent2;
                                woo = new Coordinate(xNum, yNum);
                            }
                        }
                    }
                }
            }

            return woo;
        }
    }
}
