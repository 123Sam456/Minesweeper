﻿//----------------------------------------------------------------------
// <copyright file="Square.cs" company="😹👍">
//     team project
// </copyright>
//----------------------------------------------------------------------
namespace VSProject
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Reveals how many mines there are around a square or if it is a mine
    /// </summary>
    public enum State
    {
        /// <summary>
        /// 0 represents no mines
        /// </summary>
        NoMines = 0,

        /// <summary>
        /// 1 represents a square has 1 mine surrounding it
        /// </summary>
        OneMine = 1,

        /// <summary>
        /// 2 represents a square has 2 mines surrounding it
        /// </summary>
        TwoMines = 2,

        /// <summary>
        /// 3 represents a square has 3 mines surrounding it
        /// </summary>
        ThreeMines = 3,

        /// <summary>
        /// 4 represents a square has 4 mines surrounding it
        /// </summary>
        FourMines = 4,

        /// <summary>
        /// 5 represents a square has 5 mines surrounding it
        /// </summary>
        FiveMines = 5,

        /// <summary>
        /// 6 represents a square has 6 mines surrounding it
        /// </summary>
        SixMines = 6,

        /// <summary>
        /// 7 represents a square has 7 mines surrounding it
        /// </summary>
        SevenMines = 7,

        /// <summary>
        /// 8 represents a square has 8 mines surrounding it
        /// </summary>
        EightMines = 8,

        /// <summary>
        /// 9 represents a square being a mine
        /// </summary>
        IsAMine = 9
    }

    /// <summary>
    /// Reveals if the square has a flag or a question mark or is a empty block
    /// </summary>
    public enum State2
    {
        /// <summary>
        /// 0 represents uncovered block 
        /// </summary>
        Blank = 0,

        /// <summary>
        /// 1 represents  question mark on a covered block
        /// </summary>
        Question = 1,

        /// <summary>
        /// 2 represents flagged block on a covered block 
        /// </summary>
        Flag = 2
    }

    /// <summary>
    /// The class used to represent a square and it's values
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "Encapsulation not yet taught.")]
    public class Square
    {
        /// <summary>
        /// state variable for when there is no mines. default is no mines
        /// </summary>
        public State State = State.NoMines;

        /// <summary>
        /// state variable. default is a blank unrevealed square
        /// </summary>
        public State2 State2 = State2.Blank;

        /// <summary>
        /// Has the player already left-clicked (revealed) the square. default is false
        /// </summary>
        public bool Revealed = false;

        /// <summary>
        /// Location of square
        /// </summary>
        public Coordinate Location;
    }
}
